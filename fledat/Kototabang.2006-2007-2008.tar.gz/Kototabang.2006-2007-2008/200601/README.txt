January 2006 

Location = Kototabang, Indonesia
Longitude = 100.32
Latitude = -0.20
Launch altitude (km) = 0.865

ECC ozonesonde + Snow White hygrometer 
+ TMAX interface (sampling time interval: 7 to 8 sec) + RS80-H 
(See the following 3 papers for Snow White hygrometers: 
Fujiwara et al., Journal of Atmospheric and Oceanic Technology (JTECH), 2003; 
Vömel (Voemel) et al., JTECH, 2003; Verver et al., JTECH, 2006) 

KT*.DE1: Description file (original, taken at the site) 
KT*FLT.DAT: Data file (original, taken at the site) 

----- 

Flight number = KT001
Date [GMT] = 06-01-2006
Time [GMT] = 02:34:31
Burst altitude (km) = 30.932

Flight number = KT002
Date [GMT] = 09-01-2006
Time [GMT] = 02:30:35
Burst altitude (km) = 31.889

Flight number = KT003
Date [GMT] = 11-01-2006
Time [GMT] = 08:38:13
Burst altitude (km) = 30.439

Flight number = KT004
Date [GMT] = 12-01-2006
Time [GMT] = 23:09:40
Burst altitude (km) = 32.686

Flight number = KT005
Date [GMT] = 14-01-2006
Time [GMT] = 22:54:04
Burst altitude (km) = 32.703

Flight number = KT006
Date [GMT] = 16-01-2006
Time [GMT] = 23:10:10
Burst altitude (km) = 31.841

Flight number = KT007
Date [GMT] = 18-01-2006
Time [GMT] = 22:52:38
Burst altitude (km) = 14.796

Flight number = KT008
Date [GMT] = 20-01-2006
Time [GMT] = 22:46:19
Burst altitude (km) = 17.757

Flight number = KT009
Date [GMT] = 22-01-2006
Time [GMT] = 23:31:50
Burst altitude (km) = 18.381

Flight number = KT010
Date [GMT] = 25-01-2006
Time [GMT] = 00:10:46
Burst altitude (km) = 31.860

----- 
