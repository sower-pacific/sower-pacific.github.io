January 2008 

Location = Kototabang, Indonesia
Longitude = 100.32
Latitude = -0.20
Launch altitude (km) = 0.864

ECC ozonesonde + CFH hygrometer + EN-SCI GPS 
+ V2C interface (sampling time interval: ~1.2 sec) + RS80-A or RS80-H 
(See the following paper for CFH hygrometers: 
Vömel et al., JGR, 2007) 

kt*fle.dat: Description and data file (quality-controlled by Holger Vömel) 

----- 

Flight number = KT031
Date [GMT] = 09-01-2008
Time [GMT] = 23:09:52
Burst altitude (km) = 31.60
Vaisala humicap sensor = A

Flight number = KT032
Date [GMT] = 11-01-2008
Time [GMT] = 22:46:33
Burst altitude (km) = 31.52
Vaisala humicap sensor = A

Flight number = KT033
Date [GMT] = 13-01-2008
Time [GMT] = 23:16:13
Burst altitude (km) = 32.89
Vaisala humicap sensor = H

Flight number = KT034
Date [GMT] = 15-01-2008
Time [GMT] = 22:55:38
Burst altitude (km) = 30.42
Vaisala humicap sensor = A

Flight number = KT035
Date [GMT] = 17-01-2008
Time [GMT] = 23:35:21
Burst altitude (km) = 32.25
Vaisala humicap sensor = A
NOTE: No CFH hygrometer -- file format is different (for o3, wind, etc.) 

----- 
