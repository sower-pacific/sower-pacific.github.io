Prepared by Masatomo Fujiwara on 3 October 2014 for Dr. Hubert Luce 
