January 2007 

Location = Kototabang, Indonesia
Longitude = 100.32
Latitude = -0.20
Launch altitude (km) = 0.864

ECC ozonesonde + CFH hygrometer + EN-SCI GPS 
+ V2C interface (sampling time interval: ~1.2 sec) + RS80-A or RS80-H 
(See the following paper for CFH hygrometers: 
Vömel et al., JGR, 2007) 

kt*fle.dat: Description and data file (quality-controlled by Holger Vömel) 

----- 
Flight number = KT021
Date [GMT] = 07-01-2007
Time [GMT] = 01:19:15
Burst altitude (km) = 33.29
Vaisala humicap sensor = A
NOTE: See kt021.readme.txt (CFH cryogen ran out in the mid troposphere) 

Flight number = KT022
Date [GMT] = 09-01-2007
Time [GMT] = 00:10:43
Burst altitude (km) = 33.44
Vaisala humicap sensor = H

Flight number = KT023
Date [GMT] = 11-01-2007
Time [GMT] = 00:51:42
Burst altitude (km) = 33.89
Vaisala humicap sensor = H

Flight number = KT024
Date [GMT] = 12-01-2007
Time [GMT] = 23:37:07
Burst altitude (km) = 34.02
Vaisala humicap sensor = H

Flight number = KT025
Date [GMT] = 14-01-2007
Time [GMT] = 23:47:15
Burst altitude (km) = 33.78
Vaisala humicap sensor = H

----- 
